# Homework-2.6
Homework 2.6 - Musayev Alisher

2 oyda o'tilgan table tegi uy fazifasi. Bajarilishga ketgan vaqt: Boshlandi 20:00 Tugadi: 03:27
Kod yozish jarayonida sass preprotsessori qo'llanilgan. 
